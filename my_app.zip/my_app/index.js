//Bibliotecas

const express = require('express');
const bodyParser = require('body-parser');
const router  = require('./router')
const Firms = require('./models/firms');
const app = express();
const sequelize = require('sequelize')
const index = require('./index')

const path = require('path')
const basePath = path.join(__dirname, 'index.html');


// Estancia do Express

app.use(bodyParser.urlencoded({ extended: true }));
//app.use(bodyparser.json())
// Usando o middleware express.json() para analisar os corpos das requisições como JSON
app.use(express.json());

// Rotas do aplicativo
app.use(router);
app.use(express.static('public'));

const port = 3000;

app.listen(port, () => {
    console.log(`On port ${port}`);
});
