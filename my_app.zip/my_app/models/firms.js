const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('testing', 'root', 'ANSKk08aPEDbFjDO', {
  host: 'localhost',
  dialect: 'mysql',
  port: 3307
});

const Firms = sequelize.define('firms', {
  id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
  locadora: {
    type: DataTypes.STRING,
    allowNull: false
  },
  marca: {
    type: DataTypes.STRING,
    allowNull: false
  },
  modelo: {
    type: DataTypes.STRING,
    allowNull: false
  },
  ano: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  motor: {
    type: DataTypes.STRING,
    allowNull: false
  },
  portas: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  cambio: {
    type: DataTypes.STRING,
    allowNull: false
  },
  arCondicionado: {
        type: DataTypes.BOOLEAN
  } 
  
});

Firms.sync()
.then(function() {
  console.log('Modelo sincronizado com o banco de dados');
})
.catch(function(error) {
  console.error(error);
});

module.exports = Firms;
