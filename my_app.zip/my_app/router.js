const path = require('path');
const express = require('express');
const router = express.Router();
const server = require('./index');
const bodyparser = require('body-parser')
const Firms = require('./models/firms');

router.get('/Incluir', (req, res) => {
  res.sendFile(__dirname + "/front/Incluir.html");
});
router.post('/Incluir', (req, res) => {
  const { id, locadora, modelo, marca, ano, motor, portas, cambio, arCondicionado } = req.body;

  let ar_Condicionado = parseInt(arCondicionado);
  if (isNaN(arCondicionado)) {

  }

  Firms.create({
    id,
    locadora,
    modelo,
    marca,
    ano,
    motor,
    portas,
    cambio,
    arCondicionado: arCondicionado
  })
    .then(function () {
      res.sendFile(__dirname + "/front/index.html");
    })
    .catch(function (error) {
      console.error(error);
    });
});

router.get('/listarVeiculos', (req, res) => {
  const htmlPath = path.resolve(__dirname + "/front/TodosVeiculos.html");
  res.sendFile(htmlPath);
});

router.get('/TodosVeiculos', (req, res) => {
  Firms.findAll({ attributes: ['id', 'locadora', 'modelo', 'marca', 'ano', 'motor', 'portas', 'cambio', 'arCondicionado'] })
    .then(function (firms) {
      const options = firms.map(firms => `
      <option value="${firms.id}">
        ID: ${firms.id}, Locadora: ${firms.locadora}, Modelo: ${firms.modelo}, Ano: ${firms.ano}, Motor: ${firms.motor}, Portas: ${firms.portas}, Câmbio: ${firms.cambio}, Ar Condicionado: ${firms.arCondicionado}
      </option>`
      );

      const select = `<select size="10">${options.join('')}</select>`;
      const voltar = `<a href="/listarVeiculos">Voltar</a>`;

      res.send(`${select}<br>${voltar}`);
    })
    .catch(function (error) {
      console.error(error);
      res.status(500).send('Erro ao recuperar veículos');
    });
});

router.get('/TodosVeiculos:id', (req, res) => {
  const id = req.params.id;

  Firms.findOne({ where: { id: id } })
    .then(function (firms) {
      if (!firms) {
        console.error('Veículo não encontrado');
        res.status(404).send('Veículo não encontrado');
        return;
      }

      // Elemento HTML select com o id "selectVeiculo"
      const selectHTML = `
        <select id="selectFirms">
          <option value size="5"="${firms.ID}">ID: ${firms.id}, Locadora: ${firms.locadora}, Modelo: ${firms.modelo}, Ano: ${firms.ano}, Motor: ${firms.motor}, Portas: ${firms.portas}, Câmbio: ${firms.cambio}, Ar Condicionado: ${firms.arCondicionado}</option>
        </select>
      `;

      // botão "Voltar" 
      const voltarButton = '<a href="/listarVeiculos">Voltar</a>';

      res.send(`${selectHTML} <br> ${voltarButton}`);
    })
    .catch(function (error) {
      console.error(error);
      res.status(500).send('Erro ao selecionar veículo');
    });
});


router.get('/alterar', (req, res) => {
  const htmlAPath = path.resolve(__dirname + "/front/Update.html");
  res.sendFile(htmlAPath);
});


// Use req.params.id para obter o ID dinâmico
router.put('/alterar/:id', async (req, res) => {
  // Obtenha o valor do ID a partir dos parâmetros da solicitação
  const id = req.params.id;

  // Certifique-se de que o ID não seja undefined ou nulo
  if (id === undefined || id === null) {
    res.status(400).send('ID inválido na solicitação');
    return;
  }

  // Continue com a lógica de atualização usando o ID
  const { locadora, modelo, marca, ano, motor, portas, cambio, arCondicionado } = req.body;

  // Construa a condição com o ID
  const condition = { id: id };

  Veiculos.update(
    {
      locadora,
      modelo,
      marca,
      ano,
      motor,
      portas,
      cambio,
      arCondicionado
    },
    {
      where: condition
    }
  )
    .then(function (result) {
      if (result[0] === 1) {
        res.status(200).send('Veículo atualizado com sucesso');
      } else {
        res.status(404).send('Veículo não encontrado');
      }
    })
    .catch(function (error) {
      console.error(error);
      res.status(500).send('Erro ao atualizar veículo');
    });
});

router.get('/Deletar/', (req, res) => {
  const htmlAPath = path.resolve(__dirname + "/front/Deletar.html");
  res.sendFile(htmlAPath);
});

router.delete('/Deletar:id', (req, res) => {
  const { id } = req.params;

  Firms.destroy({
    where: {
      id: id
    }
  })
    .then(function () {
      res.send('Dados deletados com sucesso!');
    })
    .catch(function (error) {
      console.error(error);
      res.status(500).send('Erro ao deletar os dados');
    });
});

router.get('/', (req, res) => {
  const htmlPath = path.resolve(__dirname + "/front/index.html");
  res.sendFile(htmlPath);
});

module.exports = router;
