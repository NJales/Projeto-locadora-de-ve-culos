Foi criada a pasta my_app, com a estrutura de inicialização pelo package.json
